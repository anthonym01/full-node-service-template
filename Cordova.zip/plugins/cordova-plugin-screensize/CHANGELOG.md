# Changelog

## v1.3.1

- add densityValue and densityBucket to Android platform

## v1.3.0

- add OSX platform

## v1.2.0

- add `xdpi` and `ydpi` values to Android platform
- add "Known Issues" section to README#Android

## v1.1.0

- add iOS and Browser platforms
