#import <Cordova/CDV.h>

@interface ScreenSize : CDVPlugin

- (void)get:(CDVInvokedUrlCommand*)command;

@end
