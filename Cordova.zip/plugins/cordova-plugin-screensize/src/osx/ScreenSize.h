#import <Cordova/CDVPlugin.h>

@interface ScreenSize : CDVPlugin

- (void)get:(CDVInvokedUrlCommand*)command;

@end
