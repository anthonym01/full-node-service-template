/// <reference path="..\.vscode\typings\cordova\plugins\Toast.d.ts"/>
/// <reference path="..\.vscode\typings\cordova\plugins\Device.d.ts"/>