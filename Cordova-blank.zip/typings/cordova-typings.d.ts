
/// <reference path="..\.vscode\typings\cordova\plugins\Toast.d.ts"/>